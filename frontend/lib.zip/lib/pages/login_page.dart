import 'package:flutter/material.dart';
import 'package:SONA/widgets/green_button.dart';
import 'package:SONA/widgets/input_box.dart';
import 'package:SONA/services/auth_service.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController controllerEmail = TextEditingController();
  TextEditingController controllerPassword = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF6F7F9),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [

                  Image.asset(
                    'assets/images/sona_logo_with_text.png',
                    height: 100,
                    width: 100,
                  ),

                  const SizedBox(height: 55),

                  const Text(
                    'Login to your account',
                    style: TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF003A3F),
                    ),
                  ),

                  const SizedBox(height: 39),

                  InputBox(
                    label: 'EMAIL',
                    placeholder: 'Enter your email',
                    controller: controllerEmail,
                  ),

                  const SizedBox(height: 30),

                  InputBox(
                    label: 'PASSWORD',
                    placeholder: 'Enter your password',
                    controller: controllerPassword,
                    isConfidential: true,
                  ),

                  const SizedBox(height: 39),

                  GreenButton(
                    text: 'Login',
                    onPressed: () async {
                      final result = await AuthService.login(
                        email: controllerEmail.text,
                        password: controllerPassword.text,
                      );

                      print(result);
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}