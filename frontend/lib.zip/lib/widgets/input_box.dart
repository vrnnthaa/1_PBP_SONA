import 'package:flutter/material.dart';

class InputBox extends StatefulWidget {
  final String label;
  final String placeholder;
  final bool isConfidential;
  final TextEditingController? controller;

  const InputBox({
    super.key,
    required this.label,
    required this.placeholder,
    this.isConfidential = false,
    this.controller,
  });

  @override
  State<InputBox> createState() => _InputBoxState();
}

class _InputBoxState extends State<InputBox> {
  bool isFocused = false;
  bool isHidden = true;

  final FocusNode focusNode = FocusNode();

  @override
  void initState() 
  {
    super.initState();

    focusNode.addListener(() {
      setState(() {
        isFocused = focusNode.hasFocus;
      });
    });
  }

  @override
  void dispose() {
    focusNode.dispose();

    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,

      children: [
        Text(
          widget.label,

          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.bold,
            color: Color(0xFF505050),
          ),
        ),

        const SizedBox(height: 8),

        AnimatedContainer(
          duration: const Duration(
            milliseconds: 200,
          ),

          decoration: BoxDecoration(
            color: const Color(0xFFF8F8F8),

            borderRadius: BorderRadius.circular(16),

            border: Border.all(
              color: isFocused ? const Color(0xFF00727C) : Colors.transparent,

              width: 2,
            ),

            boxShadow: [
              BoxShadow(
                color: Colors.black12,

                blurRadius: 8,

                offset: const Offset(0, 2),
              ),
            ],
          ),

          child: TextField(
            focusNode: focusNode,
            controller: widget.controller,

            obscureText: widget.isConfidential ? isHidden : false,

            decoration: InputDecoration(
              hintText: widget.placeholder,

              hintStyle: const TextStyle(
                color: Color(0xFFA29EB6),
                fontSize: 14,
              ),

              border: InputBorder.none,

              contentPadding: 
                const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 18,
                ),

                suffixIcon: widget.isConfidential
                  ? IconButton(
                    onPressed: () {
                      setState(() {
                        isHidden = !isHidden;
                      });
                    },

                    icon: Icon(isHidden ? Icons.visibility_off : Icons.visibility, color: Colors.grey),
                  )
                  : null,
            ),
          )
        )
      ],
    );
  }
}